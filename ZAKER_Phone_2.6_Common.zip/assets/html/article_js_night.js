function insertContentTitle(time, auther, title, Color) {
    var content_title = document.getElementById("content_title");
    var article_time = document.getElementById("article_time");
    var article_auther = document.getElementById("article_auther");
    var article_title = document.getElementById("article_title");
    var aritcle_title_bottomline = document.getElementById("aritcle_title_bottomline");
    content_title.style.display = "block";
    article_time.innerHTML = time;
    article_title.innerHTML = "<b>" + title + "</b>";
    article_auther.innerHTML = auther;
    aritcle_title_bottomline.style.display = "block";

}

function showContentTextLoading() {
    var content_text = document.getElementById("content_text");
    content_text.style.display = "block";
    content_text.innerHTML = "<div align='center'><font color='#828282' size='3'>文章读取中...</font></div>";
}

function insertContentText(HTMLString, Color, Size) {
    var content_text = document.getElementById("content_text");
    content_text.style.display = "block";
    content_text.innerHTML = HTMLString;
    content_text.style.backgroundColor = Color;
    content_text.style.fontSize = Size + 'px';
    content_text.style.lineHeight = '140%';
}
function insertContentTextForContent(HTMLString, Color, Size,Url) {
    var content_text = document.getElementById("content_text");
    var original = document.getElementById("original");
    original.style.display="block";
    original.href=Url;
    content_text.style.display = "block";
    content_text.innerHTML = HTMLString;
    content_text.style.backgroundColor = Color;
    content_text.style.fontSize = Size + 'px';
    content_text.style.lineHeight = '140%';
}
function showCommentLoading(HTMLString, HtmlURL, isShow) {
    var content_comment_state_url = document.getElementById("content_comment_state_url");
    var content_comment_state = document.getElementById("content_comment_state");
    var content_comment_topline = document.getElementById("content_comment_topline");
    var no_comment = document.getElementById("no_comment");
    no_comment.style.display = "none";
    content_comment_topline.style.display = "block";
    content_comment_state.style.display = isShow;
    content_comment_state_url.innerHTML = HTMLString;
    content_comment_state_url.href = HtmlURL;
}

function clearCommit() {
    var content_comment_text = document.getElementById('content_comment_text');
    content_comment_text.innerHTML = '';
}

function insertCommentraw(from, image, time, content) {
    var commmit = document.getElementById('content_comment_text');
    var div1 = document.createElement('div');
    var div2 = document.createElement('div');
    var div3 = document.createElement('div');
    var div4 = document.createElement('div');
    var div5 = document.createElement('div');
    var div6 = document.createElement('div');
    var img = document.createElement('img');
    var br = document.createElement('br');

    div1.style.display = "";
    div2.style.display = "";
    div3.style.display = "";
    div4.style.display = "";
    div5.style.display = "";
    div6.style.display = "";

    div1.className = 'list';
    div2.className = 'img';
    div3.className = 'main';
    div4.className = 'title';
    div5.className = 'content';
    div6.className = 'line';
    img.src = image;
    img.className = 'imgs'
    br.className = 'clear'

    div2.appendChild(img);
    div3.appendChild(div4);
    div3.appendChild(div5);
    div1.appendChild(div2);
    div1.appendChild(div3);
    div1.appendChild(br);
    div4.innerHTML = from + "<span align='center' style='color:rgb(130, 130, 130);'>" + time + "</span>";
    div5.innerHTML = content;
    div6.appendChild(div1);
    commmit.appendChild(div6);
}

function insertImageSrc(str, index) {
    var img = document.getElementById('id_image_' + index);
    var imgbox = document.getElementById('id_imagebox_' + index);
    if (imgbox != undefined) {
        imgbox.style.height = "auto";
    }
    img.src = str;
    img.onclick = function() {
        downloadImage(index);
        return false;
    }
    img.style.height = "auto";
    img.style.width = "100%";
}


function insertContentTitle_push(auther, title, Color) {
    var content_title = document.getElementById("content_title");
    var article_auther = document.getElementById("article_auther");
    var article_title = document.getElementById("article_title");
    var aritcle_title_bottomline = document.getElementById("aritcle_title_bottomline");
    content_title.style.borderTop = "solid 0px " + Color;
    content_title.style.display = "block";
    article_title.innerHTML = "<b>" + title + "</b>";
    article_auther.innerHTML = auther;
    aritcle_title_bottomline.style.display = "block";
    article_auther.style.background = Color;
}

function downloadImage(mess) {
    document.location.href = "image" + mess

}
function isNight(flag) {
    var css = document.getElementById("css");
    var content_title = document.getElementById("content_title");
    var article_auther = document.getElementById("article_auther");
    if (flag) {
        css.href = "style_normal.css";
        content_title.style.borderTop = "solid 4px " + " rgb(44, 167, 234)";
        article_auther.style.background = "rgb(44, 167, 234)";
    } else {
        css.href = "style_night.css";
        content_title.style.borderTop = "solid 4px " + " #313131";
        article_auther.style.background = "#313131";
    }
}

function changeTextSize(Size) {
    var content_text = document.getElementById("content_text");
    content_text.style.fontSize = Size + 'px';
}