package com.xyz.effect;

import java.util.Random;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class FirstActivity extends Activity implements OnClickListener{
    /** Called when the activity is first created. */
    
    private Button mBtn;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_layout);
        
        mBtn = (Button) findViewById(R.id.btn);
        mBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        if(v == mBtn) {
            // 放在overridePendingTransition 之后就不起作用啦
            startActivity(new Intent(getApplicationContext(), SecondActivity.class));
            Random rand = new Random();
            int opt = rand.nextInt(4);
            switch(opt) {
            case 0:
                // 淡入淡出
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                break;
            case 1:
                // 左近右出
                overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                break;
            case 2:
                // 放大缩小
                overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
                break;
            case 3:
                // 旋转
                overridePendingTransition(R.anim.rotate_zoomin, R.anim.rotate_zoomout);
                break;
            }
        }
    }
}