//create widgetOne IO manager object
var ioManager = new WidgetOneIOMan();
function dial(phone) {
	if (phone == null) {
		return;
	}
	phone = String(phone);
	phone = phone.replace(/\D+/gi, "").replace(/\s+/gi, "");
	if(phone.length <= 0){
		return;
	}
	var phone_obj = ioManager.open("Call");
	phone_obj.open(null, null);
	phone_obj.write(phone, phone.length, 0);
	phone_obj.ioctl(1, 0, 0);
}
//if file not exist then return "",else return file content
//callback can is null
function readFile(file_path, callback) {
	var result = "";
	var file_obj = ioManager.open("File System");
	file_obj.open(file_path, 0);
	if (callback != null) {
		file_obj.onnotify = callback;
	}
	var len = getFileLength(file_path);
	if (len != -1 && len > 0) {
		result = file_obj.read(len + 1, 0);
	}
	file_obj.close();
	return result;
}
//if file not exist then return -1,else return length of file content
function getFileLength(file_path) {
	if(file_path == null){
		return -1;
	}
	var file_obj = ioManager.open("FileManager");
	file_obj.open(file_path, 0);
	var len = file_obj.ioctl(1, 0, 0);
	file_obj.close();
	return len;
}
function strByteLen(str){
	if(str == null){
		return 0;
	}
	var added_len = 0;
	for(var i=0;i<str.length;i+=1){
		//chinese "·"
		if(str.charCodeAt(i)==0xb7){
			added_len += 1;
		}
	}
	var tmp_ = str;
	return tmp_.replace(/[^\x00-\xff]/gi, "---").length + added_len;
}
//callback can is null
function writeFile(file_path, content, callback) {
	if(file_path == null){
		return;
	}
	forceCreateParentDir(file_path);
	if (content == null) {
		content = "";
	} else {
		content = String(content);
	}
	/*var tmp_ = content;
	var len = tmp_.replace(/[^\x00-\xff]/gi, "---").length;*/
	var len = strByteLen(content);
	var file_obj = ioManager.open("File System");
	file_obj.open(file_path, 1);
	if (callback != null) {
		file_obj.onnotify = callback;
	}
	file_obj.write(content, len, 1);
	file_obj.close();
}
//append content to end of file
function appendFile(file_path, content, callback){
	if(file_path == null || content == null){
		return;
	}
	forceCreateParentDir(file_path);
	var file_obj = ioManager.open("File System");
	file_obj.open(file_path, 4);
	if(callback != null){
		file_obj.onnotify = callback;
	}
	/*var tmp_ = content;
	var len = tmp_.replace(/[^\x00-\xff]/gi, "---").length;*/
	var len = strByteLen(content);
	file_obj.write(content, len, 2);
	file_obj.close();
}
//if file's parent dir not exist,then create it.
function forceCreateParentDir(file_path){
	if(file_path == null){
		return;
	}
	if(!existFile(file_path)){
		var split_ = file_path.split("/");
		if(split_.length > 1){
			createDir(split_.slice(0, split_.length - 1).join("/"));
		}
	}
}
//callback can is null
function openCamera(callback) {
	var camera_obj = ioManager.open("CAMERA");
	camera_obj.open(null, null);
	if (callback != null) {
		camera_obj.onnotify = callback;
	}
	camera_obj.ioctl(0, 0, 0);
}
//callback can is null
function sendSms(phone, content, callback) {
	if (phone == null || content == null) {
		return;
	}
	phone = String(phone);
	phone = phone.replace(/\D+/gi, "").replace(/\s+/gi, "");
	if(phone.length <= 0){
		return;
	}
	content = String(content);
	var sms_obj = ioManager.open("SMS");
	sms_obj.open(null, null);
	if (callback != null) {
		sms_obj.onnotify = callback;
	}
	sms_obj.write(phone, phone.length, 0);
	sms_obj.write(content, content.length, 1);
	sms_obj.ioctl(2, 0, 0);
}
function sendCms(msg) {
	//send colorful message
}
//callback can is null
function openFileManager(callback) {
	var fileManager = ioManager.open("FileManager");
	fileManager.open(null, null);
	if(callback != null){
		fileManager.onnotify = callback;
	}
	fileManager.ioctl(0, 0, 0);
}
function loadApp(appName, callback) {
	if(appName == null){
		return;
	}
	appName = String(appName);
	var app_loader = ioManager.open("LoadApp");
	app_loader.open(null, null);
	if (callback != null) {
		app_loader.onnotify = callback;
	}
	app_loader.ioctl(0, 0, 0);
	app_loader.write(appName, appName.length, 1);
}
//callback can is null
function openVideo(callback) {
	var video_obj = ioManager.open("Video");
	video_obj.open(null, null);
	if (callback != null) {
		video_obj.onnotify = callback;
	}
	video_obj.ioctl(0, 0, 0);
}
function openPhonebook(callback) {
	var phonebook_obj = ioManager.open("PhoneBook");
	phonebook_obj.open(null, null);
	if (callback != null) {
		phonebook_obj.onnotify = callback;
	}
	phonebook_obj.ioctl(0, 0, 0);
}
//callback can is null
function addPhone(phone, callback) {
	if (phone == null) {
		return;
	}
	phone = String(phone);
	var phonebook_obj = ioManager.open("PhoneBook");
	phonebook_obj.open(null, null);
	if (callback != null) {
		phonebook_obj.onnotify = callback;
	}
	phonebook_obj.write(phone, phone.length, 1);
}
//file or directory exist or not(not useful now)
function existFile(file_path) {
	if (file_path == null) {
		return false;
	}
	var file_obj = ioManager.open("FileManager");
	file_obj.open(file_path, 0);
	var exist = file_obj.ioctl(5, 0, 0);
	file_obj.close();
	return exist == 1;
}
//create ddirectory by input dir_path
function createDir(dir_path) {
	if (dir_path == null || dir_path.replace(/\s+/, "").length <= 0) {
		return false;
	}
	dir_path = String(dir_path);
	if(! existFile(dir_path)){
		var	split_ = dir_path.split("/");
		var dir_tmp = "";
		var i_ = 0;
		if(split_.length > 1){
			while(split_.length > 0){
				dir_tmp = split_.slice(0, split_.length - 1).join("/");
				createDir(dir_tmp);
				split_.pop();
			}
		}
		var fileManager = ioManager.open("FileManager");
		fileManager.open(dir_path, 0);
		var success = fileManager.ioctl(7, 0, 0);
		fileManager.close();
		return success == 0;
	}
	return true;
}
//whether input file_path is a directory or not
function isDir(file_path) {
	if (file_path == null || file_path.replace(/\s+/, "").length <= 0) {
		return false;
	}
	var file_obj = ioManager.open("FileManager");
	file_obj.open(file_path, 0);
	var isDir_ = file_obj.ioctl(6, 0, 0);
	file_obj.close();
	return isDir_ > 0;
}
//whether input file_path is a file or not
function isFile(file_path) {
	if (file_path == null || file_path.replace(/\s+/, "").length <= 0) {
		return false;
	}
	var file_obj = ioManager.open("FileManager");
	file_obj.open(file_path, 0);
	var isDir_ = file_obj.ioctl(6, 0, 0);
	file_obj.close();
	return isDir_ == 0;
}
//delete directory, return true if delete successfully, otherwise return false.
function deleteDir(dir_path){
	if(dir_path == null){
		return false;
	}
	var fileManager = ioManager.open("FileManager");
	fileManager.open(dir_path, 0);
	var delDir = fileManager.ioctl(8,0,0);
	fileManager.close();
	return delDir == 0;
}
//delete file, return true if delete successfully, otherwise return false.
function deleteFile(file_path){
	if(file_path == null){
		return false;
	}
	var fileManager = ioManager.open("FileManager");
	fileManager.open(file_path, 0);
	var delFile = fileManager.ioctl(9,0,0);
	fileManager.close();
	return delFile == 0;
}
//get widgetOne version
function getWidgetOneVersion(){
	var fileManager = ioManager.open("WO");
	fileManager.open("", 0);
	var version = filemanager.read(100, 0);
	fileManager.close();
	return version;
}
//create ajax core 
function createXMLHTTPRequest(){
  	return new XMLHttpRequest();
}
//get filename of old remoteurl
function gettempfilename(remoteurl){
	var f_name = remoteurl.substr(remoteurl.lastIndexOf('/')+1);
	return f_name;	
}
//create pic , return true if suc  otherwise return false
function createpic(url,fold,file,callback){
	if(url == null || fold == null || file == null){
		return;
	}
	var xmlHttp = null;
	xmlHttp= createXMLHTTPRequest();
	xmlHttp.onreadystatechange = function(){
		if (xmlHttp.readyState == 4){
			if (xmlHttp.status == 200){
				var file_obj = ioManager.open("File System");
				createDir(fold);
				var f_f = fold + (fold.lastIndexOf("/") == (fold.length - 1) ? "" : "/") + file;
				//if(existFile(f_f)==false){
					file_obj.open(f_f, 1);
					xmlHttp.localResponseBodySession(file_obj);
					file_obj.close();
				//}
				if(callback != null){
					callback();
				}
			}
		}
	}
	xmlHttp.open("get",url, true);
	xmlHttp.send(null);
}