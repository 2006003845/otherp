var root = "local/images/";
var dirs = ["1","2","3","4","5","6","7","8","9"];
var files = [{"ico": "ico.jpg","imgs": ["1.jpg","2.jpg","3.jpg","4.jpg"]},
			{"ico": "ico.jpg","imgs": ["1.png","2.jpg","3.jpg","4.jpg"]},
			{"ico": "ico.jpg","imgs": ["1.jpg","2.jpg","3.jpg","4.jpg"]},
			{"ico": "ico.jpg","imgs": ["1.jpg","2.jpg","3.jpg","4.jpg"]},
			{"ico": "ico.jpg","imgs": ["1.jpg","2.jpg","3.jpg","4.jpg"]},
			{"ico": "ico.jpg","imgs": ["1.jpg","2.jpg","3.jpg","4.jpg"]},
			{"ico": "ico.jpg","imgs": ["1.jpg","2.jpg","3.jpg","4.jpg"]},
			{"ico": "ico.jpg","imgs": ["1.jpg","2.jpg","3.jpg","4.jpg"]},
			{"ico": "ico.jpg","imgs": ["1.jpg","2.jpg","3.jpg","4.jpg"]}
			];
var names = ["图书馆","酒店内","镜头前","会议室","马路边","营业厅","超市里","阳台上","洗手间"];