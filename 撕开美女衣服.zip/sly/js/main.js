var ip="127.0.0.1";
var baseurl = "http://"+ip+"/sileyuan/api.php"
var getcom_cout_url = baseurl+"?jsoncallback=?&m=count";
var get_com_list = baseurl+"?jsoncallback=?&m=list&page=";
var send_com = baseurl+"?jsoncallback=?&m=comment";

function trim(s) {   
   var count = s.length;   
   var st    = 0;       // start   
   var end   = count-1; // end   
   
   if (s == "") return s;   
   while (st < count) {   
     if (s.charAt(st) == " ")   
       st ++;   
     else  
       break;   
   }   
   while (end > st) {   
     if (s.charAt(end) == " ")   
       end --;   
     else  
       break;   
   }   
   return s.substring(st,end + 1);   
}  
function strByteLen(str){
	if(str == null){
		return 0;
	}
	var added_len = 0;
	for(var i=0;i<str.length;i+=1){
		//chinese "·"
		if(str.charCodeAt(i)==0xb7){
			added_len += 1;
		}
	}
	var tmp_ = str;
	return tmp_.replace(/[^\x00-\xff]/gi, "---").length + added_len;
}
/**/
if(! isOnWidgetOne()){
	window.onload=function(){
		alterCss();
		init();
	};
}else{
	document.onanimationend=function(){
		init();
	};
}
function init(){
	//do something and in every page override this method
}
function alterCss(){
	if(! isOnWidgetOne()){
		var css1=document.createElement("link");
		css1.rel="stylesheet";
		css1.type="text/css";
		css1.href="css/320x480/index.css";
		document.body.appendChild(css1);
	}
}
function isOnWidgetOne(){
	return "undefined" != typeof WidgetOneIOMan;
}
//parse parameters in url
//params: {"a": 1,"c": 8}
var params = {};
function parseParam(){
	var loc = String(document.location);
	if(loc.indexOf('?')>=0){
		var pieces = loc.substr(loc.indexOf('?') + 1).split('&');
		params.keys=[];
		for (var i = 0; i < pieces.length; i+=1){
		    var keyVal = pieces[i].split('=');
		    params[keyVal[0]] = decodeURIComponent(keyVal[1]);
		    params.keys.push(keyVal[0]);
		}
	}
}
function encodeParam(param_){
	if(param_ != null){
		return encodeURIComponent(param_);
	}
	return null;
}
var looked_imgs = {};
var file_have_looked = "local/looked.xml";
function getLooked(){
	var img_str = zy_readFile(file_have_looked ,zy_getFileSize(file_have_looked));
	try{
		looked_imgs = img_str == null ? {} : JSON.parse(img_str);
	}catch(e){
		looked_imgs = {};
	}
	looked_imgs = looked_imgs || {};
}
function setLooked(){
	zy_writeFile(file_have_looked, JSON.stringify(looked_imgs || {}), null);
}
function go_back(){
	window.history.back();
}
function quit(){
	self.close();
}
window.location.loadhrefaction="ts_mover_left_to_right";
document.onlefttoright=go_back;
document.onkeysoft2=go_back;
function quit(){
	self.close();
}