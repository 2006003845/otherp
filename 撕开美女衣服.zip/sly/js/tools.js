/**/
(function(){
	llc = {};
	llc.getJSON = function(url, data, callback){
		var funcName="jsonp"+(new Date().getTime());
		if(callback != null && "[object Function]" == Object.prototype.toString.call(callback)){
			eval(""+funcName+" = function(json){try{callback(json);}catch(e){}finally{"+funcName+"=null;delete "+funcName+";}}");
		}
		var default_id = "script4ajax_123456";
		var element = document.getElementById(default_id);
		if(element != null){
			document.body.removeChild(element);
		}
		element = document.createElement("script");
		var tmp_10 = mergeUrlWithParam(url, llc.createUrlParam(data));
		if(tmp_10 != null){
			tmp_10 = tmp_10.replace("jsoncallback", "_" + new Date().getTime());
		}
		element.src = mergeUrlWithParam(tmp_10, "jsoncallback="+funcName+"&_1_2="+(new Date().getTime()));
		element.type = "text/javascript";
		element.language = "javascript";
		element.id = default_id;
		document.body.appendChild(element);
	};
	function mergeUrlWithParam(url, param_str){
		if(url != null){
			if(param_str != null && param_str.indexOf("=") != -1){
				if(param_str.indexOf("&") == 0){
					param_str = param_str.substr(1);
				}
				var wenhao_index = url.indexOf("?");
				if(wenhao_index == -1){
					return url + "?" + param_str;
				}else{
					if(wenhao_index == url.length - 1){
						return url + param_str;
					}else{
						return url + "&" + param_str;
					}
				}
			}
			return url;
		}
		return "";
	}
	function object2UrlParams(obj, parent){
		var arr=[];
		if(obj != null){
			for(var k in obj){
				var val=obj[k];
				var type_=typeof val;
				if("string" == type_ || "number" == type_ || "boolean" == type_ ){
					arr.push((parent== null ? "" : (parent+"."))+k+"="+encodeParam(val));
				}else{
					arr=arr.concat(object2UrlParams(val, k))
				}
			}
		}
		return arr;
	}
	//将object(hash或string)转换为url参数格式(eg:a=1&a.r=2&b=3)
	llc.createUrlParam = function (obj){
		var url_params="";
		if(obj != null){
			if("string" == typeof obj){
				url_params = obj;
			}else{
				var arr_ = object2UrlParams(obj, null);
				if(arr_ != null){
					url_params = arr_.join("&");
				}
			}
		}
		return url_params;
	}
})(window);
function ajaxPost(url, data, callback_functions){
	ajaxGeneral("post", url, data, callback_functions);
}
function ajaxGet(url, data, callback_functions){
	ajaxGeneral("get", url, data, callback_functions);
}
//callback_functions:{loadstart: function(){},progress: function(){},load: function(){},abort: function(){},error: function(){},parseError: function(){}}
function ajaxGeneral(requestMethod, url, data, callback_functions){
	/*on widgetOne platform there are: onabort,onerror,onload,onloadstart,onprogress*/
	var success = callback_functions.load;
	if(isOnWidgetOne()){
		var xmlHttp = new XMLHttpRequest();
		xmlHttp.onabort=function(){
			if(callback_functions && callback_functions.abort){
				callback_functions.abort();
			}
		};
		xmlHttp.onerror=function(){
			//trigger when there is an connection error or aborted
			//如果访问url的主域不存在,激活onerror事件而非onabort
			if(callback_functions && callback_functions.error){
				callback_functions.error();
			}
		};
		xmlHttp.onload=function(){
			//trigger when successfully load the url
			//如果访问url的主域存在,不论后台404或500等都会是4&200(onload)状态
			//4&200即是onload,所以此处暂时为空
		};
		xmlHttp.onloadstart=function(){
			//trigger when start loading the url
			if(callback_functions && callback_functions.loadstart){
				callback_functions.loadstart();
			}
		};
		xmlHttp.onprogress=function(){
			//trigger when progress response result
			if(callback_functions && callback_functions.progress){
				callback_functions.progress();
			}
		};
		var parse_error = callback_functions.parseError;
		xmlHttp.onreadystatechange = function(){
			if (xmlHttp.readyState == 4) {
				if (xmlHttp.status == 200) {
					if(success != null){
						var index_left = xmlHttp.responseText.indexOf("(");
						var json_str = index_left != -1 ? xmlHttp.responseText.substr(index_left) : ("("+xmlHttp.responseText+")");
						try{
							success(eval(json_str));
						}catch(e){
							//error when parsing response result,and trigger function "parseError" if it is defined
							if(parse_error){
								parse_error();
							}
						}
					}
				}
			}
		};
		xmlHttp.open(requestMethod, url, true);
		xmlHttp.send(llc.createUrlParam(data));
	}else{
		llc.getJSON(url, data, success);
	}
}
function isOnWidgetOne(){
	return "undefined" != typeof WidgetOneIOMan;
}
function encodeParam(param_){
	if(param_ != null){
		return encodeURIComponent(param_);
	}
	return null;
}
function $$(id){
	if(id != null){
		if("string" == typeof(id)){
			return document.getElementById(id);
		}else{
			return id;
		}
	}
	return null;
}
function addClass(id, className){
	if(className == null){
		return;
	}
	var ele = $$(id);
	if(ele != null){
		var old_class = getAttr(ele, "className");
		old_class = old_class || "";
		if(old_class.indexOf(className) != -1){
			return;
		}
		var arr_ = old_class.split(/\s+/gi);
		arr_ = arr_ || [];
		arr_.push(className);
		setAttr(ele, "className", arr_.join(" "));
	}
}
function removeClass(id, className){
	if(className == null){
		return;
	}
	var ele = $$(id);
	if(ele != null){
		var old_class = getAttr(ele, "className");
		old_class = old_class || "";
		if(old_class.indexOf(className) == -1){
			return;
		}
		var arr_ = old_class.split(/\s+/gi);
		arr_ = arr_ || [];
		for(var i in arr_){
			if(className == arr_[i]){
				arr_.splice(i, 1);
				break;
			}
		}
		setAttr(ele, "className", arr_.join(" "));
	}
}
function getAttr(id, name){
	var ele=$$(id);
	if(ele != null){
		if(name != null){
			var tmp=ele[name];
			if(tmp != null){
				return tmp;
			}
		}
	}
	return null;
}
function setAttr(id, name, value){
	var ele=$$(id);
	if(ele != null){
		if(name != null){
			if(value != null){
				ele[name]=value;
			}else{
				//delete ele[name];
			}
		}
	}
}
function setText(id, text){
	setAttr(id, "textContent", text);
}
function setValue(id, value){
	setAttr(id, "value", value)
}
function getValue(id){
	return getAttr(id, "value")
}
function setHtml(id, html){
	setAttr(id, "innerHTML", html == null ? "" : html);
}
function getHtml(id){
	var tmp=getAttr(id, "innerHTML");
	return tmp == null ? "" : tmp;
}
function setCss(id, name, value){
	var obj = $$(id);
	if (obj != null && name != null) {
		if(value != null){
			obj.style[name] = value;
		}else{
			delete obj.style[name];
		}
	}
}
function getCss(id, css_name){
	var obj = $$(id);
	if (obj != null && css_name != null) {
		if(Sys.ie){
			//IE
			return obj.currentStyle[css_name];
		}else if(document.defaultView){
			//FireFox
			return document.defaultView.getComputedStyle(obj, null)[css_name];
		}
	}
}
function showEle(id){
	//document.getElementById(id).style.display="block";
	setCss(id, "display", "block");
}
function hideEle(id){
	//document.getElementById(id).style.display="none";
	setCss(id, "display", "none");
}
function isArray(obj){
	return obj && "[object Array]" == Object.prototype.toString.call(obj);
}
var Sys = {};
var ua = navigator.userAgent.toLowerCase();
var s;
(s = ua.match(/msie ([\d.]+)/)) ? Sys.ie = s[1] :
(s = ua.match(/firefox\/([\d.]+)/)) ? Sys.firefox = s[1] :
(s = ua.match(/chrome\/([\d.]+)/)) ? Sys.chrome = s[1] :
(s = ua.match(/opera.([\d.]+)/)) ? Sys.opera = s[1] :
(s = ua.match(/version\/([\d.]+).*safari/)) ? Sys.safari = s[1] : 0;
/**/