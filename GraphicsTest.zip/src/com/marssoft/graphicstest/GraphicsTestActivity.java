package com.marssoft.graphicstest;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

/**
 * ʵ�������ڵ�ͼ���ƶ���
 * @author Mars.CN
 *
 */
public class GraphicsTestActivity extends Activity {
	private TestView view  = null;
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	view= new TestView(this);
    	requestWindowFeature(Window.FEATURE_NO_TITLE);
    	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);		//����Ϊȫ��
        super.onCreate(savedInstanceState);
        setContentView(view);
    }
//    @Override
//    public boolean onKeyDown(int keyCode, KeyEvent event) {
//    	return view.onKeyDown(keyCode, event);
//    }
//    @Override
//    public boolean onKeyUp(int keyCode, KeyEvent event) {
//    	return view.onKeyUp(keyCode, event);
//    }
    
}