package com.flysnow.widget;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FloatTextToastActivity extends Activity {
	private Button mBtn1;
	private Button mBtn2;
	private TextView mIntroTv;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mBtn1=(Button)findViewById(R.id.btn_1);
        mBtn2=(Button)findViewById(R.id.btn_2);
        mIntroTv=(TextView)findViewById(R.id.intro_tv);
        
        FloatTextToast.makeText(this, mBtn1, "有新功能哦，点我试试看", FloatTextToast.LENGTH_LONG).show();
        mBtn2.setOnClickListener(mBtn2CliclListener);
        
        mIntroTv.setTextColor(Color.BLUE);
        mIntroTv.setOnClickListener(mIntroTvCliclListener);
    }

	private View.OnClickListener mBtn2CliclListener =new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			FloatTextToast.makeText(FloatTextToastActivity.this, v, "这是一个测试按钮", FloatTextToast.LENGTH_LONG).show();
		}
	};
	private View.OnClickListener mIntroTvCliclListener =new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			String introText="昵称：michael_li(飞雪无情)\n" +
							"博客：http://blog.csdn.net/michael__li";
			FloatTextToast.makeText(FloatTextToastActivity.this, v, introText, FloatTextToast.LENGTH_LONG).show();
		}
	};
}