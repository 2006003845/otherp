/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hadeslee.yoyoplayer.skin;

import java.io.File;

/**
 * 用于解析千千静听的皮肤并提供一系列的方法
 * 得到这个皮肤下面的所有的属性以及图片内容
 * 等等
 * @author binfeng.li
 */
public class TTSkinParser {

    public TTSkinParser(File file) {
    }
}
