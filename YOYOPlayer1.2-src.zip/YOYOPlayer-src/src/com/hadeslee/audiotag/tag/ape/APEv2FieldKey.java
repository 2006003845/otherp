/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hadeslee.audiotag.tag.ape;

/**
 *
 * @author hadeslee
 */
public enum APEv2FieldKey {

    Artist,
    Album,
    Genre,
    Title,
    Year,
    Track,
    Comment

}
