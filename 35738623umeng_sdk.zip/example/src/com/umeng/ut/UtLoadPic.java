package com.umeng.ut;

import android.app.Activity;
import android.os.Bundle;

import com.umeng.example.R;

public class UtLoadPic extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.umeng_ut_loadpic);
	}
	
}
