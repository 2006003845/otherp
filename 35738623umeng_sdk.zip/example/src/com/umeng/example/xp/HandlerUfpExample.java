package com.umeng.example.xp;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.umeng.example.R;
import com.umeng.ui.BaseSinglePaneActivity;
import com.umeng.xp.common.ExchangeConstants;
import com.umeng.xp.controller.ExchangeDataService;
import com.umeng.xp.view.ExchangeViewManager;

/**
 * 小把手展示样例
 * @author Lucas Xu
 *
 */
public class HandlerUfpExample extends BaseSinglePaneActivity {

	/**
	 * 此id 为http://ufp.umeng.com 友盟UFP (Umeng For Publisher) 系统添加的广告位ID。
	 * 相关注册说明请咨询友盟客服。
	 */
	private static final String SLOT_ID_Handler = "40167";
	@Override
	protected Fragment onCreatePane() {
		return new HandlerExampleFragment();
	}
	
	public static class HandlerExampleFragment extends Fragment{
		Context mContext;
		
		@Override
	    public void onAttach(Activity activity) {
	        super.onAttach(activity);
	        mContext = activity;
	    }
		
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View root = inflater.inflate(
					R.layout.umeng_example_xp_banner_activity, container,
					false);
			com.umeng.common.Log.LOG = true;
			
			/**
			 * 两种方式的逻辑不同 模式1 请求数据在现实ImageView  之前 模式2 请求数据将在ImageView 点击之后
			 */
			
			//把手图片服务器提供 云端不配置图片将不显示
//			final ExchangeDataService exchangeDataService = new ExchangeDataService(SLOT_ID_Handler);
//			ImageView imageview = (ImageView) root.findViewById(R.id.imageview);
//			new ExchangeViewManager(mContext, exchangeDataService)
//				.addView(ExchangeConstants.type_list_curtain, imageview);
//			
//			
//			
//			final ExchangeDataService exchangeDataService2 = new ExchangeDataService(SLOT_ID_Handler);
//			ImageView imageview2 = (ImageView) root.findViewById(R.id.imageview2);
//			new ExchangeViewManager(mContext, exchangeDataService2)
//				.addView(ExchangeConstants.type_list_curtain, imageview2,mContext.getResources().getDrawable(R.drawable.umeng_example_handler));
			
			
			
			// ViewGroup 
			final ExchangeDataService exchangeDataService3 = new ExchangeDataService(SLOT_ID_Handler);
			RelativeLayout relayout1 = (RelativeLayout) root.findViewById(R.id.rlayout1);
			exchangeDataService3.setTemplate(0);
			new ExchangeViewManager(mContext, exchangeDataService3)
				.addView(ExchangeConstants.type_list_curtain, relayout1);
			
//			final ExchangeDataService exchangeDataService4 = new ExchangeDataService(SLOT_ID_Handler);
//			RelativeLayout relayout2 = (RelativeLayout) root.findViewById(R.id.rlayout2);
//			new ExchangeViewManager(mContext, exchangeDataService4)
//				.addView(ExchangeConstants.type_list_curtain, relayout2,mContext.getResources().getDrawable(R.drawable.umeng_example_handler));
			
			return root;
		}
		
	}
	
}