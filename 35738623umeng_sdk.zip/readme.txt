友盟Android SDK
文档请参考： http://dev.umeng.com/doc/document_ana_android.html
