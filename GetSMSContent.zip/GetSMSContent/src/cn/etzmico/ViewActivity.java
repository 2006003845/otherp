package cn.etzmico;

import android.app.Activity;
import android.os.Bundle;

public class ViewActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

}