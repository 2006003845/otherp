package Sudoku.xwg;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;

public class SudokuPanel extends Activity {
	private static final int RESET_GAME_ID = 0;
	private static final int AUTO_FILL_ID = RESET_GAME_ID + 1;
	private static final int SAVE_GAME_ID = AUTO_FILL_ID + 1;
	private static final int LOAD_GAME_ID = SAVE_GAME_ID + 1;
	
	public static final String KEY_DATA_ID = "DataIndex";
	public static final String KEY_WORK_MODE  = "WorkMode";
	private static final String DIALOG_ARG_KEY_MSG	= "DialogMessage";
	
	private static final int DIALOG_MESSAGE_ID = 0;
	
		
	public static final int ACTIVITY_CREATE = 0;
	public static final int ACTIVITY_EDIT = 1;
	public static final int ACTIVITY_PLAY = 2;
		
	private SudokuEngine mData;
	private SudokuGridAdapter mAdapter = null;
	private SudokuDbAdapter mDbHelper;
	private Long mRowId;
	private Integer mMode;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sudoku_panel);
        
        mDbHelper = new SudokuDbAdapter(this);
	    mDbHelper.open();
	    
	    Bundle extras = getIntent().getExtras();
	    EditText titleEdit = (EditText)findViewById(R.id.editTitle);
        
	    mMode = null;
        mRowId = null;
        if(savedInstanceState != null){
        	mRowId =  (Long) savedInstanceState.getSerializable(KEY_DATA_ID);
        	mMode = (Integer)savedInstanceState.getSerializable(KEY_WORK_MODE);
        }
        
        if (mRowId == null) {
        	mRowId = ((extras != null) ? extras.getLong(KEY_DATA_ID) : null); 
        }
        if (mMode == null){
        	mMode = ((extras != null) ? extras.getInt(KEY_WORK_MODE) : 0);
        }
        
        if (mRowId == null){
        	mData = new SudokuEngine(9, mMode != ACTIVITY_PLAY);
        }else{
        	Cursor c = mDbHelper.fetchNotes(mRowId);
			startManagingCursor(c);
			String title = c.getString(c.getColumnIndexOrThrow(SudokuDbAdapter.KEY_TITLE));
			titleEdit.setText(title);
			String body = c.getString(c.getColumnIndexOrThrow(SudokuDbAdapter.KEY_BODY));
			mData = new SudokuEngine(body, mMode != ACTIVITY_PLAY);
        }
        titleEdit.setEnabled(mMode != ACTIVITY_PLAY);
        
        GridView sudokuGrid = (GridView)findViewById(R.id.sudokuGrid);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        mAdapter = new SudokuGridAdapter(this, metrics.widthPixels, mData);
        sudokuGrid.setSelector(R.drawable.grid_selector);
        sudokuGrid.setAdapter(mAdapter);
        sudokuGrid.setOnItemClickListener(new OnItemClickListener(){
    		public void onItemClick(AdapterView<?> parent, View v, int position, long id){
    			mAdapter.onItemClick(parent, v, position, id);
    			
    			int row = position / mData.getSize();
    			int col = position % mData.getSize();
    			int[] btnId = {R.id.btn_num_1, R.id.btn_num_2, R.id.btn_num_3, R.id.btn_num_4, R.id.btn_num_5,
    					R.id.btn_num_6, R.id.btn_num_7, R.id.btn_num_8, R.id.btn_num_9};
    			
    			int[] btnUsable = new int[btnId.length];
    			int[] usableNumbers = mData.getUsableNumber(row, col);
    			if(usableNumbers != null){
    				for(int i = 0; i < usableNumbers.length; ++i){
    					btnUsable[usableNumbers[i] - 1] = 1;
    				}
				}
    			for(int i = 0; i < btnId.length; ++i){
    				Button btn = (Button)findViewById(btnId[i]);
    				btn.setEnabled(btnUsable[i] == 1);
    			}
   			}    
		});
    }
    
    
    
    @Override
	protected Dialog onCreateDialog(int id, Bundle args) {
		switch(id){
		case DIALOG_MESSAGE_ID:
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage(args.getString(DIALOG_ARG_KEY_MSG))
				.setCancelable(false)
				.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {						
					}
				});       
			return builder.create();
		}
		return null;
	}



	public void OnNumberButton(View v){
    	switch(v.getId()){
    	case R.id.btn_num_1:
    		setCurrentItem(1);
    		break;
    	case R.id.btn_num_2:
    		setCurrentItem(2);
    		break;
    	case R.id.btn_num_3:
    		setCurrentItem(3);
    		break;
    	case R.id.btn_num_4:
    		setCurrentItem(4);
    		break;
    	case R.id.btn_num_5:
    		setCurrentItem(5);
    		break;
    	case R.id.btn_num_6:
    		setCurrentItem(6);
    		break;
    	case R.id.btn_num_7:
    		setCurrentItem(7);
    		break;
    	case R.id.btn_num_8:
    		setCurrentItem(8);
    		break;
    	case R.id.btn_num_9:
    		setCurrentItem(9);
    		break;
    	case R.id.btn_undo:
    		undo();
    		break;
    	}
    }
    
    boolean setCurrentItem(int number){
    	int position = mAdapter.getCurrentPosition();
		int row = position / mData.getSize();
		int col = position % mData.getSize();
		if(mData.setNumber(row, col, number, mData.isQuestionMode())){
			mAdapter.updateCurrentItem();
			return true;
		}else{
			GridView sudokuGrid = (GridView)findViewById(R.id.sudokuGrid);
			sudokuGrid.setAdapter(mAdapter);
			Bundle args = new Bundle();
			args.putString(DIALOG_ARG_KEY_MSG, mData.getErrorMessage());
			showDialog(DIALOG_MESSAGE_ID, args);
		}
		
		return false;
    }
    
    boolean undo(){
    	mData.undo();
    	GridView sudokuGrid = (GridView)findViewById(R.id.sudokuGrid);
    	sudokuGrid.setAdapter(mAdapter);
    	return true;
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		GridView sudokuGrid = (GridView)findViewById(R.id.sudokuGrid);
		switch(item.getItemId()){
		case RESET_GAME_ID:
			mData.reset();
			sudokuGrid.setAdapter(mAdapter);
			break;
		case AUTO_FILL_ID:
			mData.applyResolvedNumbers();
			sudokuGrid.setAdapter(mAdapter);
			break;
		case SAVE_GAME_ID:
			 EditText titleEdit = (EditText)findViewById(R.id.editTitle);
			if(mRowId == null){
				long id = mDbHelper.createNote(titleEdit.getText().toString(), mData.getDataString());
				if(id > 0){
					mRowId = id;
				}
			} else {
				mDbHelper.updateNote(mRowId, titleEdit.getText().toString(), mData.getDataString());
			}
			break;
		case LOAD_GAME_ID:
			break;
		}
		return true;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		boolean result = super.onCreateOptionsMenu(menu);
		if(mData.isQuestionMode()){
			menu.add(0, RESET_GAME_ID, 0, R.string.str_clear);
			menu.add(0, SAVE_GAME_ID, 0, R.string.str_save_game);
		} else {
			menu.add(0, RESET_GAME_ID, 0, R.string.str_clear);
			menu.add(0, AUTO_FILL_ID, 0, R.string.str_auto_fill);
		}
		return result;
	}
	
    
}