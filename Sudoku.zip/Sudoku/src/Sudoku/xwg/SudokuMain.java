package Sudoku.xwg;

import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class SudokuMain extends ListActivity {
	private SudokuDbAdapter mDbHelper;
	public static final int INSERT_ID = Menu.FIRST;
	public static final int PLAY_ID = INSERT_ID + 1;
	public static final int EDIT_ID = PLAY_ID + 1;
	public static final int RENAME_ID = EDIT_ID + 1;
	public static final int DELETE_ID = RENAME_ID + 1;
	
	Cursor mNoteCursor;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mDbHelper = new SudokuDbAdapter(this);
        mDbHelper.open();
        registerForContextMenu(getListView());
        fillData();
    }
    
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		boolean result = super.onCreateOptionsMenu(menu);
		menu.add(0, INSERT_ID, 0, R.string.menu_insert);
		return result;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId())
		{
		case INSERT_ID:
			createNode();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
		
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		super.onCreateContextMenu(menu, v, menuInfo);
		menu.add(0, EDIT_ID, 0, R.string.menu_edit);
		menu.add(0, DELETE_ID, 0, R.string.menu_delete);
	}
	
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		AdapterContextMenuInfo info = (AdapterContextMenuInfo)item.getMenuInfo();
		switch(item.getItemId()){
		case EDIT_ID:
			startSudokuPanel(SudokuPanel.ACTIVITY_EDIT, info.id);
			return true;
		case DELETE_ID:
			mDbHelper.deleteNode(info.id);
			fillData();
			return true;
		}
		return super.onContextItemSelected(item);
	}
	
	private void startSudokuPanel(int mode, long row_id){
		Intent i = new Intent(this, SudokuPanel.class);
		i.putExtra(SudokuPanel.KEY_DATA_ID, row_id);
		i.putExtra(SudokuPanel.KEY_WORK_MODE, mode);
		startActivityForResult(i, mode);
	}

	
	private void createNode(){
		Intent i = new Intent(this, SudokuPanel.class);
		startActivityForResult(i, SudokuPanel.ACTIVITY_CREATE);
	}
	
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
		startSudokuPanel(SudokuPanel.ACTIVITY_PLAY, id);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		fillData();
	}

	private void fillData(){
		Cursor c = mDbHelper.fetchAllNotes();
		startManagingCursor(c);
		
		String[] from = new String[] {SudokuDbAdapter.KEY_TITLE};
		int[] to = new int[]{R.id.game_title};
		
		SimpleCursorAdapter note = 
			new SimpleCursorAdapter(this, R.layout.game_data_row, c, from ,to);
		setListAdapter(note);
	}
}