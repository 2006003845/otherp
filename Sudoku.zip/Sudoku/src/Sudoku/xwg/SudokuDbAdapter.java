package Sudoku.xwg;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class SudokuDbAdapter {
	private static final String TAG = "SudokuDbAdapter";
	
	private SQLiteDatabase m_db;
	private Context m_context;
		
	private static final String SUDOKU_DB_NAME = "sudoku_db";
	
	private static final String SUDOKU_DATA_TABLE = "sudoku_data_table";
	
	public static final String KEY_TITLE = "title";
	public static final String KEY_SIZE = "size";
    public static final String KEY_BODY = "body";
    public static final String KEY_ROWID = "_id";
	
	public class SudokuDbHelper extends SQLiteOpenHelper
	{
		private static final int DB_VERSION = 3;
		private static final String DATABASE_CREATE =
	        "create table " + SUDOKU_DATA_TABLE + "(" + KEY_ROWID + " integer primary key autoincrement, "
	        + KEY_TITLE + " text not null, " + KEY_BODY + " text not null);";
		
		SudokuDbHelper(Context context)
		{
			super(context, SUDOKU_DB_NAME, null, DB_VERSION);
		}
		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);
			//Initialize database
			ContentValues values = new ContentValues();
			values.put(KEY_TITLE, "Level1-1");
			values.put(KEY_BODY, "9,-1,-2,-4,-5,0,0,0,0,0,0,0,-7,0,0,-8,0,0,0,0,-3,0,0,-9,0,-6,-7,0,0,0,-9,-7,-8,-4,-3,-1,0,0,-1,0,0,-5,-2,0,-4,0,-7,0,-8,-6,0,-3,0,0,-2,-5,-8,-2,-4,0,-9,-1,-6,0,0,-9,-3,-1,-6,0,-2,-8,-5,-6,-7,0,0,0,-5,-4,-3,0");
			db.insert(SUDOKU_DATA_TABLE, null , values);
			values.put(KEY_TITLE, "Level2-1");
			values.put(KEY_BODY, "9,0,0,0,0,0,0,0,0,0,-7,-4,0,0,0,0,0,-3,0,0,0,0,-2,-1,0,0,0,0,0,0,-1,0,0,0,-5,0,-2,0,0,0,-9,0,-7,0,0,0,0,0,-8,0,0,0,0,0,0,-9,0,-2,0,0,0,0,0,0,0,0,0,0,0,-4,0,-7,-3,0,0,0,0,-3,0,0,0,0");
			db.insert(SUDOKU_DATA_TABLE, null , values);
		}
		@Override
		public void onOpen(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			super.onOpen(db);
		}
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS " + SUDOKU_DATA_TABLE);
            onCreate(db);
		}
	}
	
	
	
	SudokuDbAdapter(Context context)
	{
		m_context = context; 
	}
	
	void open()
	{
		SudokuDbHelper helper = new SudokuDbHelper(m_context);
		m_db = helper.getWritableDatabase();
	}
	
	void close()
	{
		m_db.close();
	}
	
	int createNote(String title, String body)
	{
		ContentValues values = new ContentValues();
		values.put(KEY_TITLE, title);
		values.put(KEY_BODY, body);
		m_db.insert(SUDOKU_DATA_TABLE, null , values);
		return 0;
	}
	
	int updateNote(long id, String title, String body)
	{
		ContentValues values = new ContentValues();
		values.put(KEY_TITLE, title);
		values.put(KEY_BODY, body);
		return m_db.update(SUDOKU_DATA_TABLE, values, KEY_ROWID + "=" + id, null);
	}
	
	boolean deleteNode(long id)
	{
		return (m_db.delete(SUDOKU_DATA_TABLE, KEY_ROWID + "=" + id, null) > 0);
	}
	
	Cursor fetchAllNotes()
	{
		return m_db.query(SUDOKU_DATA_TABLE, null, null, null, null, null, null);
	}
	
	Cursor fetchNotes(long id)
	{
		//return 
		Cursor mCursor = m_db.query(SUDOKU_DATA_TABLE, null, KEY_ROWID + "=" + id, null, null, null, null);

	//		m_db.query(true, NOTE_DB_TABLE, new String[] {KEY_ROWID, KEY_TITLE, KEY_BODY},
	//		m_db.query(true, NOTE_DB_TABLE, null,
    //        		KEY_ROWID + "=" + id, null,null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
	}
}
