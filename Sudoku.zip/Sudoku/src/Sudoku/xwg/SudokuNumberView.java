package Sudoku.xwg;

import android.content.Context;
import android.graphics.Canvas;
import android.widget.TextView;

public class SudokuNumberView extends TextView {
	public SudokuNumberView(Context context) {
        super(context);
    }

	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.onDraw(canvas);
	}
}
