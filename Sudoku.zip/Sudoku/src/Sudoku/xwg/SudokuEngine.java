package Sudoku.xwg;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Vector;

import android.util.Log;

public class SudokuEngine {
	private int mSize = 0;
	private int mBlockSize = 0;
	private Vector<SudokuCell> mData = null;
	private boolean mQuestionMode = true;
	private String mQuestionString = null;
	private String mErrorMsg = null;
	LinkedList<SudokuCommand> mCommandList = new LinkedList<SudokuCommand>();
	
	private static final String TAG = new String("SudokuEngine");
	
	class SudokuCell {
		boolean mQuestionNumber = false;
		int mNumber = 0;
		LinkedList<Integer> usableNumberList = new LinkedList<Integer>();
		
		SudokuCell(int size){
			for(int n = 0; n < size; ++n){
				addUsableNumber(n + 1);
			}
		}
		
		void reset(int number, boolean questionNumber, int[] usableNumber){
			mNumber = number;
			mQuestionNumber = questionNumber;
			usableNumberList.clear();
			for(int i = 0; i < usableNumber.length; ++i){
				addUsableNumber(usableNumber[i]);
			}
		}
		
		boolean setNumber(int number, boolean questionNumber){
			Integer intNumber = new Integer(number);
			if(usableNumberList.contains(intNumber)){
				usableNumberList.clear();
				mNumber = number;
				mQuestionNumber = questionNumber;
				return true;
			}else{
				mErrorMsg = String.format("Can to set value to %d", number);
				return false;
			}
		}
		
		boolean applyResolvedNumber(){
			if(mNumber == 0 && isResolved()){
				setNumber(usableNumberList.getFirst(), false);
				return true;
			}else{
				return false;
			}
		}
		
		boolean isQuestionNumber(){
			return mQuestionNumber;
		}
		
		boolean isResolved(){
			return (usableNumberList.size() == 1);
		}
		boolean isSet(){
			return (usableNumberList.size() == 0 && mNumber > 0);
		}
		
		int getResolved(){
			if(isResolved()){
				return usableNumberList.getFirst();
			}else{
				return 0;
			}
		}
		
		int getNumber()
		{
			return mNumber;
		}
		
		boolean removeUsableNumber(int number){
			return usableNumberList.remove(new Integer(number));
		}
		
		boolean addUsableNumber(int number){
			usableNumberList.add(number);
			Collections.sort(usableNumberList);
			return true;
		}
		
		boolean isNumberUsable(int number){
			return usableNumberList.contains(number);
		}
		
		int[] getUsableNumber(){
			if(usableNumberList.size() > 0){
				int[] usableNumber = new int[usableNumberList.size()];
				for(int i = 0; i < usableNumberList.size(); ++i){
					usableNumber[i] = usableNumberList.get(i);
				}
				return usableNumber;
			}else{
				return null;
			}
		}
		
		int getUsableNumberCount(){
			return usableNumberList.size();
		}
		
		String getLogString(int width){
			String strLog = new String();
			for(int i = 0; i < usableNumberList.size(); ++i){
				strLog += usableNumberList.get(i);
			}
			strLog += ":";
			strLog += mNumber;
			while(strLog.length() < width){
				strLog += " ";
			}
			return strLog;
		}
	}
	
	public class SetNumberInfo{
		int mRow = 0;
		int mCol = 0;
		int mNumber = 0;
		SetNumberInfo(int row, int col, int number){
			mRow = row;
			mCol = col;
			mNumber = number;
			//Log.i(TAG, String.format("Cell(%d,%d) is resolved to %d", row, col, number));
		}
	}
	
	class SudokuCommand{
		boolean execute(){return true;}
		boolean undo(){return true;}
	}
	
	class MacroCommand extends SudokuCommand
	{
		LinkedList<SudokuCommand> mCommandList = new LinkedList<SudokuCommand>();
		void addCommand(SudokuCommand cmd){
			mCommandList.add(cmd);
		}
		int getCommandCount(){
			return mCommandList.size();
		}
		boolean execute(){
			Iterator<SudokuCommand> it = mCommandList.iterator();
			while(it.hasNext()){
				SudokuCommand cmd = it.next();
				if(!cmd.execute()){
					return false;
				}
			}
			return true;
		}
		boolean undo(){
			Iterator<SudokuCommand> it = mCommandList.iterator();
			while(it.hasNext()){
				SudokuCommand cmd = it.next();
				if(!cmd.undo()){
					return false;
				}	
			}
			return true;
		}
	}
	
	class SetNumberCommand extends SudokuCommand
	{
		SudokuCell mCell;
		int mNumber;
		boolean mQuestionNumber;
		int[] mUsableNumber;
		
		SetNumberCommand(SudokuCell cell, int number, boolean questionNumber){
			mCell = cell;
			mNumber = number;
			mQuestionNumber = questionNumber;
		}
		
		boolean execute(){
			mUsableNumber = mCell.getUsableNumber();
			int number = mCell.getNumber();
			boolean questionNumber = mCell.isQuestionNumber();
			if(mCell.setNumber(mNumber, mQuestionNumber)){
				mNumber = number;
				mQuestionNumber = questionNumber;
				return true;
			}else{
				return false;
			}
		}
		
		boolean undo(){
			int number = mCell.getNumber();
			boolean questionNumber = mCell.isQuestionNumber();
			mCell.reset(mNumber, mQuestionNumber, mUsableNumber);
			mNumber = number;
			mQuestionNumber = questionNumber;
			mUsableNumber = null;
			return true;
		}
	}
	
	class RemoveUsableNumberCommand extends SudokuCommand{
		SudokuCell mCell;
		int mNumber;
		RemoveUsableNumberCommand(SudokuCell cell, int number){
			mCell = cell;
			mNumber = number;
		}
		boolean execute(){
			return mCell.removeUsableNumber(mNumber);
		}
		boolean undo(){
			return mCell.addUsableNumber(mNumber);
		}
	}
	
	class ApplyResolvedNumberCommand extends SudokuCommand{
		SudokuCell mCell;
		boolean mQuestionNumber;
		ApplyResolvedNumberCommand(SudokuCell cell){
			mCell = cell;
		}
		boolean execute(){
			mQuestionNumber = mCell.isQuestionNumber();
			return mCell.applyResolvedNumber();
		}
		boolean undo(){
			int usableNumber[] = {mCell.getNumber()};
			mCell.reset(0, mQuestionNumber, usableNumber);
			return true;
		}
	}
	
	SudokuEngine(int size, boolean questionMode){
		mQuestionMode = questionMode;
		construct(size);
	}
	
	public SudokuEngine(String strData, boolean questionMode){
		mQuestionMode = questionMode;
		construct(strData);
		mQuestionString = strData;
	}
	
	void construct(int size){
		mSize = size;
		mBlockSize = (int)Math.sqrt(mSize);
		mData = new Vector<SudokuCell>();
		for(int i = 0; i < size * size; ++i){
			
			mData.add(new SudokuCell(size));
			mSize = size;
		}
	}
	
	public void construct(String strData){
		int find_start = 0;
		int find_index = 0;
		int data_index = 0;
		while((find_index = strData.indexOf(',', find_start)) > 0){
			String valueString = strData.substring(find_start, find_index);
			int value = Integer.parseInt(valueString);
			if(data_index == 0)
			{
				construct(value);
			}else{
				//if mQuestionMmode == ture, set the all cell to question mode.
				setNumber((data_index - 1) / mSize, (data_index - 1) % mSize, Math.abs(value), (mQuestionMode || value <0));
			}
			++data_index;
			find_start = find_index + 1;
		}
		
		//Question number is only can't be undo in Play mode.
		if(!mQuestionMode){
			mCommandList.clear();
		}
	}
	
	boolean undo(){
		if(mCommandList.size() > 0){
			SudokuCommand cmd = mCommandList.removeLast();
			cmd.undo();
			//OutputLog();
			return true;
		}else{
			mErrorMsg = new String("Can't undo");
			return false;
		}
	}
	
	void setQuestionMode(boolean questionMode){
		mQuestionMode = questionMode;
	}
	
	int getSize(){
		return mSize;
	}
	
	int[] getUsableNumber(int row, int col){
		SudokuCell cell = mData.get(row * mSize + col);
		return cell.getUsableNumber();
	}
	
	int getUsableNumberCount(int row, int col){
		SudokuCell cell = mData.get(row * mSize + col);
		return cell.getUsableNumberCount();
	}
	
	void reset(){
		mCommandList.clear();
		if(mQuestionString == null){
			construct(mSize);
		}else{
			construct(mQuestionString);
		}
	}
	
	String getDataString(){
		String strData = String.valueOf(mSize);
		for(int i = 0; i < mSize * mSize; ++i){
			strData += ",";
			int number = mData.get(i).getNumber();
			if(mQuestionMode){
				number = -number;
			}
			strData += String.valueOf(number);
		}
		return strData;
	}
	
	boolean setNumber(int row, int col, int number, boolean questionMode){
		SudokuCell selected = mData.get(row * mSize + col);
		if(!mQuestionMode && selected.isQuestionNumber()){
			return false;
		}
		
		SetNumberCommand cmd = new SetNumberCommand(selected, number, questionMode); 
		
		if(cmd.execute()){
			MacroCommand macro = new MacroCommand();
			macro.addCommand(cmd);
			LinkedList<SetNumberInfo> list = new LinkedList<SetNumberInfo>();
			list.add(new SetNumberInfo(row, col, number));
			while(list.size() > 0){
				list = onNumberResolved(list, macro);
			}
			if(macro.getCommandCount() > 0){
				mCommandList.add(macro);
			}
			//OutputLog();
			return checkResult();
		}else{
			return false;
		}
	}
	
	boolean checkResult(){
		for(int i = 0; i < mData.size(); ++i){
			SudokuCell cell = mData.get(i);
			if(cell.getNumber() == 0 && cell.getUsableNumberCount() ==0){
				mErrorMsg = "The are some cell can't be resolved.";
				return false;
			}
		}
		return true;
	}
	
	int getNumber(int row, int col){
		SudokuCell cell = mData.get(row * mSize + col);
		return cell.getNumber();
	}
	
	boolean isQuestionMode(){
		return mQuestionMode;
	}
	
	boolean isQuestionNumber(int row, int col){
		SudokuCell cell = mData.get(row * mSize + col);
		return cell.isQuestionNumber();
	}
	
	LinkedList<SetNumberInfo> onNumberResolved(LinkedList<SetNumberInfo> listIn, MacroCommand macro){
		LinkedList<SetNumberInfo> listOut = new LinkedList<SetNumberInfo>();
		while(listIn.size() > 0)
		{
			int col = 0;
			int row = 0;
			SetNumberInfo info = listIn.removeFirst();
			//remove the number in same row
			for(col = 0; col < mSize; ++col){
				if(col != info.mCol){
					SudokuCell cell = mData.get(info.mRow * mSize + col);
					if(cell.isNumberUsable(info.mNumber)){
						RemoveUsableNumberCommand cmd = new RemoveUsableNumberCommand(cell, info.mNumber);
						cmd.execute();
						macro.addCommand(cmd);
						if(cell.isResolved())
						{
							listOut.add(new SetNumberInfo(info.mRow, col, cell.getResolved()));
						}
					}
				}
			}
			//remove the number in same column
			for(row = 0; row < mSize; ++row){
				if(row != info.mRow){
					SudokuCell cell = mData.get(row * mSize + info.mCol);
					if(cell.isNumberUsable(info.mNumber)){
						RemoveUsableNumberCommand cmd = new RemoveUsableNumberCommand(cell, info.mNumber);
						cmd.execute();
						macro.addCommand(cmd);
						if(cell.isResolved())
						{
							listOut.add(new SetNumberInfo(row, info.mCol, cell.getResolved()));
						}
				    }
				}
			}
			//remove the number in the same block
			for(row = info.mRow / mBlockSize * mBlockSize; row < (info.mRow / mBlockSize * mBlockSize + mBlockSize); ++row){
				for(col = info.mCol / mBlockSize * mBlockSize; col < (info.mCol / mBlockSize * mBlockSize + mBlockSize); ++col){
					if(row != info.mRow && col != info.mCol){
						SudokuCell cell = mData.get(row * mSize + col);
						if(cell.isNumberUsable(info.mNumber)){
							RemoveUsableNumberCommand cmd = new RemoveUsableNumberCommand(cell, info.mNumber);
							cmd.execute();
							macro.addCommand(cmd);
							if(cell.isResolved())
							{
								listOut.add(new SetNumberInfo(row, col, cell.getResolved()));
							}
					    }
					}
				}
			}
		}
		//OutputLog();
		return listOut;
	}
	
	void applyResolvedNumbers(){
		MacroCommand macro = new MacroCommand();
		for(int i = 0; i < mData.size(); ++i){
			SudokuCell cell = mData.get(i);
			if(cell.isResolved()){
				ApplyResolvedNumberCommand cmd = new ApplyResolvedNumberCommand(cell);
				cmd.execute();
				macro.addCommand(cmd);
			}
		}
		if(macro.getCommandCount() > 0){
			mCommandList.add(macro);
		}
		//OutputLog();
	}
	
	String getErrorMessage(){
		return mErrorMsg;
	}
	
	void OutputLog(){
		Log.i(TAG, "===========================================================================================================");
		for(int r = 0; r < mSize; ++r){
			String strLog = new String();
			for(int c = 0; c < mSize; ++c){
				SudokuCell cell = mData.get(r * mSize + c);
				strLog += cell.getLogString(mSize + 3);
			}
			Log.i(TAG, strLog);
		}
	}
}
