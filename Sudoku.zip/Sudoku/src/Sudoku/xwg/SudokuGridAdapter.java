package Sudoku.xwg;

import android.content.Context;
import android.graphics.Color;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;

public class SudokuGridAdapter extends BaseAdapter{
	private Context mContext;
	private int mGridWidth = 0;
	private SudokuEngine mData;
	private View mCurrentView = null;
	
	public SudokuGridAdapter(Context c, int gridWidth, SudokuEngine data) {
		mContext = c;
		mGridWidth = gridWidth;
		mData = data;
	}
	
	public int getCount() {
		return mData.getSize() * mData.getSize();    
	}
	
	public Object getItem(int position) {
		return null;
	}
	
	public long getItemId(int position) 
	{
		return position;
	} 
	// create a new ImageView for each item referenced by the Adapter    
	public View getView(int position, View convertView, ViewGroup parent) {  
		TextView textView;
		if (convertView == null) {  
			// if it's not recycled, initialize some attributes
			textView = new SudokuNumberView(mContext);
			textView.setLayoutParams(new GridView.LayoutParams(mGridWidth / (mData.getSize() + 1), mGridWidth / (mData.getSize() + 1))); 
			textView.setPadding(0, 0, 0, 0);  
		} else {
			textView = (TextView) convertView;
		}
		
		textView.setId(position);
		textView.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
		
		setNumber(textView);
		textView.setBackgroundColor(getItemBackground(textView));
		textView.setTextColor(Color.rgb(0, 0, 0));
		return textView;
	}  
	void onItemClick(AdapterView<?> parent, View v, int position, long id){
		if(v != mCurrentView)
		{
			View prevActive = mCurrentView;
			mCurrentView = v;
			if(prevActive != null){
				prevActive.setBackgroundColor(getItemBackground(prevActive));
			}
			if(v != null){
				v.setBackgroundColor(getItemBackground(v));
			}
		}
	}
	
	int getItemBackground(View v)
	{
		int position = v.getId();
		int row = position / mData.getSize();
		int col = position % mData.getSize();
		
		//position in single block
		int blk_row = row / (int)Math.sqrt(mData.getSize());
		int blk_col = col / (int)Math.sqrt(mData.getSize());
		
		if(v != mCurrentView)
		{
			int usableNumberCount = mData.getUsableNumberCount(row, col);
			int number = mData.getNumber(row, col);
			if(usableNumberCount == 0 && number == 0){
				//The cell can't be resolved.
				return Color.rgb(255, 127, 127);
			}else{
				if((blk_row + blk_col) % 2 == 0){
					return Color.rgb(192, 255, 255);
				}else{
					return Color.rgb(192, 255, 192);
				}
			}
		} else {
			if((blk_row + blk_col) % 2 == 0){
				return Color.rgb(0, 255, 255);
			}else{
				return Color.rgb(0, 255, 0);
			}
		}
	}
	
	boolean updateCurrentItem(){
		if(mCurrentView == null) return false;
		setNumber((TextView)mCurrentView);
		return true;
	}
	
	int getCurrentPosition(){
		if(mCurrentView == null) return -1;
		return mCurrentView.getId();
	}
	
	void setNumber(TextView v){
		int position = v.getId();
		int row = position / mData.getSize();
		int col = position % mData.getSize();
		int number = mData.getNumber(row, col);
		boolean editable = !mData.isQuestionNumber(row, col);
		if(number != 0){
			String strNumber = String.format(new String("%d"), number);
			if(editable){
				v.setTextSize(TypedValue.COMPLEX_UNIT_PX, mGridWidth / mData.getSize() / 2);
			}else{
				v.setTextSize(TypedValue.COMPLEX_UNIT_PX, mGridWidth / mData.getSize() / 4 * 3);
			}
			v.setText(strNumber);
		}else{
			v.setText("");
		}	
	}
}

